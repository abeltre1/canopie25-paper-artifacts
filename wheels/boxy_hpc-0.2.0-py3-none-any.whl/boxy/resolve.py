"""v2 auto-resolution: turn a bare MODEL argument into a runnable Box+Location.

This is the RamaLama-style front door: `boxy serve <model>` with zero files.
Every decision made here is (a) printed so the user sees what was chosen,
(b) overridable by a flag, and (c) snapshottable to TOML for reproducibility.

Design rules (from the v2 design review):
  * syntax decides what a MODEL is (scheme => remote, else local path) —
    filesystem state never changes the meaning of a command;
  * a scheduler is NEVER auto-wrapped; on a login node boxy refuses to run
    an LLM server unless --here is given;
  * runtimes are probed for viability (`podman info`), not just PATH presence;
  * default ports are bind-tested and advanced when busy; explicit --port wins.
"""

from __future__ import annotations

import os
import re
import shutil
import socket
import subprocess
from dataclasses import dataclass

from boxy import ramalama_shim
from boxy.box import TRANSPORT_SCHEMES, Box
from boxy.location import Location, Resources

# Accelerators that can run vLLM (a default image exists for each).
VLLM_ACCELS = ("cuda", "rocm", "intel")


@dataclass
class Resolution:
    box: Box
    location: Location
    decisions: list[str]  # human-readable "chose X because Y" lines


def _slug(model: str) -> str:
    base = model.rsplit("/", 1)[-1]
    base = re.sub(r"\.(gguf|safetensors)$", "", base, flags=re.I)
    slug = re.sub(r"[^a-zA-Z0-9_.-]+", "-", base).strip("-").lower() or "model"
    return f"boxy-{slug}"[:63]


def looks_like_gguf(model: str) -> bool:
    # ollama registries serve GGUF blobs; treat the transport as GGUF.
    # Extension of the FINAL path component only: '/data/models.gguf/x' is a
    # directory name, not a GGUF file (sweep finding 20).
    if model.lower().startswith("ollama://"):
        return True
    base = model.rstrip("/").rsplit("/", 1)[-1].lower()
    return base.endswith(".gguf")


def infer_engine(model: str, accelerator: str, gpus: int = 0) -> tuple[str, str]:
    """(engine, reason). GGUF/ollama -> llama.cpp. Otherwise vLLM, which needs a GPU
    (detected here, or requested via --gpus for a scheduler submission)."""
    if model.lower().startswith("ollama://"):
        return "llama.cpp", "ollama models are GGUF"
    if looks_like_gguf(model):
        return "llama.cpp", "model is GGUF"
    if accelerator in VLLM_ACCELS:
        return "vllm", f"safetensors/HF repo + {accelerator} GPU"
    if gpus > 0 and accelerator in VLLM_ACCELS + ("none",):
        # 'none' = submitting from a GPU-less node; a non-vLLM accelerator
        # (vulkan/asahi/...) must not sail into the CUDA-only vLLM image
        # (sweep finding 21).
        return "vllm", f"safetensors/HF repo + --gpus {gpus} requested for the job"
    base = model.rstrip("/").rsplit("/", 1)[-1]
    accel_note = ("no GPU was detected on this host" if accelerator == "none"
                  else f"this host's accelerator is {accelerator!r}, which vLLM's images do not "
                       f"support (supported: {', '.join(VLLM_ACCELS)})")
    raise RuntimeError(
        f"model {model!r} is a safetensors/HF repo: that needs vLLM, and {accel_note}.\n"
        f"  CPU serving here:  use a GGUF build with llama.cpp — search huggingface.co for\n"
        f"      '{base} GGUF' (publishers like TheBloke, bartowski, QuantFactory), then:\n"
        f"      boxy serve hf://<owner>/<repo>/<file>.gguf\n"
        f"      (on a wrong file name, boxy lists the repo's actual GGUF files)\n"
        f"      — or skip repo guessing entirely:  boxy serve ollama://<name>\n"
        f"  GPU cluster:       this command works as-is on a GPU node; from a login node submit it:\n"
        f"      boxy serve {model} --scheduler slurm|flux --gpus N --accelerator cuda|rocm\n"
        f"  Or override:       --engine/--accelerator if detection is wrong on this host."
    )


# Presence on PATH is not viability: HPC nodes routinely carry a podman binary
# with no subuid ranges or with containers-storage on NFS, and docker binaries
# whose daemon the user cannot reach. Probe before committing.
_PROBES: dict[str, list[str]] = {
    "podman": ["info", "--format", "{{.Host.Arch}}"],
    "docker": ["info", "--format", "{{.ServerVersion}}"],
    "apptainer": ["version"],
    # charliecloud is opt-in (experimental): not in the autodetect tuple below,
    # but probeable when pinned via --runtime/a system card. Its binary is ch-run.
    "charliecloud": ["--version"],
}


def _runtime_works(candidate: str, timeout_s: float = 10.0) -> bool:
    try:
        subprocess.run(
            [candidate] + _PROBES[candidate],
            capture_output=True,
            timeout=timeout_s,
            check=True,
        )
        return True
    except Exception:
        return False


def detect_runtime() -> tuple[str, str]:
    skipped: list[str] = []
    for candidate in ("podman", "docker", "apptainer"):
        if not shutil.which(candidate):
            continue
        if not _runtime_works(candidate):
            skipped.append(f"{candidate} is on PATH but its probe failed")
            continue
        note = f"{candidate} found on PATH and responding"
        if skipped:
            note += f" ({'; '.join(skipped)})"
        return candidate, note
    if skipped:
        raise RuntimeError(
            "no working container runtime: " + "; ".join(skipped) + ". "
            "Rootless podman needs /etc/subuid entries and non-NFS storage; "
            "docker needs a reachable daemon; on HPC try `module load apptainer`."
        )
    raise RuntimeError(
        "no container runtime found (looked for podman, docker, apptainer); "
        "load your site's container module (e.g. `module load apptainer`) or install one"
    )


def detect_scheduler_context(here: bool = False) -> tuple[str, str]:
    """v2 default: NEVER auto-wrap with a scheduler. Inside an allocation, run
    direct (the job step owns the server). On a login node (scheduler CLI on
    PATH, no allocation env), REFUSE unless --here: an LLM server on a shared
    login node is the canonical acceptable-use violation."""
    if os.environ.get("SLURM_JOB_ID"):
        return "none", f"inside Slurm allocation {os.environ['SLURM_JOB_ID']} — running direct on this node"
    if os.environ.get("FLUX_ENCLOSING_ID") or os.environ.get("FLUX_JOB_ID"):
        return "none", "inside Flux allocation — running direct on this node"
    for probe, sched, alloc_hint in (
        ("srun", "slurm", "srun -N1 --gpus-per-node=1 --pty bash"),
        ("flux", "flux", "flux run -N1 -g1"),
    ):
        if shutil.which(probe):
            if here:
                return "none", f"{sched} present but --here given — running direct on THIS node"
            raise RuntimeError(
                f"this looks like a {sched} login node ({probe} on PATH, no allocation env). "
                f"Serving an LLM here is usually against site policy. Either:\n"
                f"  submit as a job:         add --scheduler {sched} --gpus N [--accelerator cuda|rocm]\n"
                f"  serve inside an alloc:   {alloc_hint}   then rerun boxy serve\n"
                f"  force this node anyway:  add --here"
            )
    return "none", "no scheduler on host"


def _port_taken(port: int) -> bool:
    # Something answering on loopback? Catches listeners the bind test can
    # miss (e.g. forwarders bound to other interfaces).
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.settimeout(0.25)
        if probe.connect_ex(("127.0.0.1", port)) == 0:
            return True
    # Wildcard bind WITHOUT SO_REUSEADDR: on macOS/BSD, SO_REUSEADDR lets a
    # 127.0.0.1 bind succeed while another process (podman-machine's gvproxy)
    # holds 0.0.0.0 on the same port — which is exactly how a "free" port
    # then dies with gvproxy's "proxy already running". (Field finding #18.)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("", port))
        except OSError:
            return True
    return False


def _free_port(preferred: int) -> tuple[int, str]:
    """Probe `preferred` and walk forward to the first free port (shared
    login/compute nodes collide on fixed defaults). Explicit --port skips this."""
    for offset in range(64):
        candidate = preferred + offset
        if _port_taken(candidate):
            continue
        return candidate, "" if offset == 0 else f"; {preferred} was busy"
    raise RuntimeError(f"no free port found in [{preferred}, {preferred + 63}]; pass --port explicitly")


def auto_location(
    runtime: str | None = None,
    scheduler: str | None = None,
    accelerator: str | None = None,
    gpus: int = 0,
    nodes: int = 1,
    here: bool = False,
    sources: dict | None = None,
    distributed: bool | None = None,
) -> tuple[Location, list[str]]:
    """Resolve the *where* (used for bare-MODEL serves and for --box without
    --location). Explicit flags win; everything else is detected and explained.
    `sources` labels where a pinned value came from ("--flag" vs "location
    profile") so decision lines never claim false provenance (r2 audit)."""
    decisions: list[str] = []
    sources = sources or {}

    if scheduler is None:
        scheduler, why = detect_scheduler_context(here=here)
        decisions.append(f"scheduler: {scheduler} ({why})")
    else:
        decisions.append(f"scheduler: {scheduler} ({sources.get('scheduler', '--scheduler')})")

    if scheduler == "none" and (gpus > 0 or nodes > 1) and not here and distributed is not True:
        # ...unless this is distributed serving (a Ray set of containers) or the
        # inner compute-node serve (--here inside an allocation), where the
        # geometry drives tensor/pipeline parallelism.
        raise RuntimeError(
            "--gpus/--nodes describe a scheduler job request and have no effect without "
            "--scheduler slurm|flux (GPU pass-through itself follows the detected accelerator). "
            "For multi-node serving on this host, add --distributed."
        )
    if nodes > 1 and gpus > 0 and (distributed is True or scheduler == "none"):
        decisions.append(f"resources: {nodes} node(s) x {gpus} GPU(s)")

    if accelerator is not None:
        decisions.append(f"accelerator: {accelerator} ({sources.get('accelerator', '--accelerator')})")
    else:
        accelerator = ramalama_shim.detect_accel()
        # boxy's HPC ladder (module-loading probe / scheduler inventory) sets a
        # note when RamaLama's own probes were blind — say WHICH probe answered
        hpc_note = ramalama_shim.last_detect_note
        if scheduler in ("slurm", "flux"):
            if accelerator == "none" and gpus > 0:
                # Turnkey: a GPU-less login node can't see the compute node's
                # device, but a novice shouldn't hit a hard error. Default it
                # (config site.default_accelerator, cuda) and say so; the compute
                # node still autodetects the real device when the job runs.
                from boxy import config

                accelerator = config.get_str("site.default_accelerator") or "cuda"
                decisions.append(
                    f"accelerator: {accelerator} (no GPU on this login node — assuming the compute "
                    f"node's; override with --accelerator or site.default_accelerator)"
                )
            elif hpc_note:
                decisions.append(f"accelerator: {accelerator} ({hpc_note})")
            else:
                decisions.append(
                    f"accelerator: {accelerator} (detected on THIS node — the compute node may differ; "
                    f"pass --accelerator or a --location profile to pin it)"
                )
        else:
            decisions.append(f"accelerator: {accelerator} ({hpc_note or 'autodetected'})")

    if runtime is None:
        runtime, why = detect_runtime()
        decisions.append(f"runtime: {runtime} ({why})")
    else:
        decisions.append(f"runtime: {runtime} ({sources.get('runtime', '--runtime')})")

    location = Location(
        name="auto",
        scheduler=scheduler,
        accelerator=accelerator,
        runtime=runtime,
        resources=Resources(nodes=nodes, gpus_per_node=gpus),
    )
    return location, decisions


# `org/name` with one slash and no path syntax — the shape of a HuggingFace repo
# id. Used ONLY to sharpen an error message; it never changes what gets resolved.
_REPO_ID_RE = re.compile(r"^[A-Za-z0-9][\w.-]*/[A-Za-z0-9][\w.-]*$")
# A trailing ".ext" of only letters — 'demo.gguf', and equally a typo'd 'demo.ggu',
# which must stay a PATH. Deliberately not a fixed extension list: a mistyped
# suffix is exactly the case where telling someone to "name the registry" is worse
# than the generic hint. Version dots survive because what follows them is not
# all-alphabetic ('Llama-3.3-70B' -> '3-70B', 'Qwen2.5-72B' -> '5-72B').
_FILE_SUFFIX_RE = re.compile(r"\.[A-Za-z]{2,12}$")


def _looks_like_repo_id(model: str) -> bool:
    """Does this read as a HuggingFace repo id rather than a path? Excludes
    anything with path syntax (leading ./ ~ /, a second slash) or a weight-file
    suffix.

    The suffix test is a shape rule, not os.path.splitext: model ids are full of
    version dots and splitext reads 'meta-llama/Llama-3.3-70B' as having the
    extension '.3-70B'."""
    if model.startswith((".", "/", "~")) or model.count("/") != 1:
        return False
    if _FILE_SUFFIX_RE.search(model):              # 'dir/model.gguf' is a path
        return False
    return bool(_REPO_ID_RE.match(model))


def _classify_model(model: str, require_exists: bool, remote_target: str = "") -> tuple[str, str]:
    """Syntax decides: a transport scheme means remote; anything else is a local
    path, full stop. Bare names are never guessed into registries — same
    command, same meaning, on every machine. Returns (resolved, decision)."""
    if model.lower().startswith("file://"):
        # RamaLama supports file:, but boxy's shared-FS flow IS a path —
        # strip the scheme instead of mangling it into a cwd-joined mount
        # (sweep finding 35).
        model = model[len("file://"):]
    scheme_split = model.split("://", 1)
    if model.lower().startswith("s3://"):
        # site-local S3 bucket: staged to the shared FS at serve time, then
        # served by path (not a RamaLama registry — origin policy N/A).
        return model, f"model: {model} (S3 bucket — staged to the shared filesystem)"
    if len(scheme_split) == 2 and scheme_split[0].lower() + "://" in TRANSPORT_SCHEMES:
        scheme, rest = scheme_split[0].lower(), scheme_split[1]
        if not rest.strip("/"):
            raise RuntimeError(
                f"malformed model URI {model!r}: nothing after the scheme "
                f"(an unset shell variable? e.g. hf://$ORG/$FILE)"
            )
        from boxy import policy

        policy.check_transport(f"{scheme}://{rest}")  # registry origin allowlist
        return f"{scheme}://{rest}", f"model: {scheme}://{rest} (transport URI — pulled via RamaLama)"
    if len(scheme_split) == 2:
        raise RuntimeError(
            f"unsupported model scheme {scheme_split[0]!r}:// — supported: "
            f"{', '.join(s[:-3] for s in TRANSPORT_SCHEMES)} (or a local path)"
        )
    resolved = os.path.abspath(model)
    if not os.path.exists(resolved):
        # an ABSOLUTE path in an --ssh invocation is a CLUSTER path — check it
        # there over the live master, not on the laptop (field: a shared-FS
        # model dir failed the local exists() and got a misleading hint)
        if remote_target and model.startswith("/"):
            import shlex

            from boxy import remote

            if remote.ensure_master(remote_target) == 0:
                rc, _ = remote.ssh_capture(remote_target,
                                           f"test -e {shlex.quote(model)}", timeout=15)
                if rc == 0:
                    host = remote_target.split("@")[-1]
                    return model, f"model: {model} (path on {host}, verified over ssh)"
            if require_exists:
                raise RuntimeError(
                    f"no such model path on {remote_target}: {model!r} (checked over the "
                    f"ssh master) — is it on a filesystem the cluster mounts?")
        # When the input ALREADY looks like a HuggingFace repo id, name the exact
        # command instead of a placeholder: 'hf://<org>/Inkling' made the reader
        # substitute an org they had already typed. Bare ids stay unresolved on
        # purpose (see this function's docstring) — the fix is to say precisely
        # what to type, not to guess.
        base = model.rsplit("/", 1)[-1]
        if _looks_like_repo_id(model):
            hint = (f"no such model file: {model!r}. A bare id is treated as a local path so "
                    f"the same command means the same thing on every machine — name the "
                    f"registry explicitly: hf://{model} (or ollama://{base})")
        else:
            hint = (f"no such model file: {model!r}. MODEL is a local path or a transport URI — "
                    f"did you mean ollama://{base} or hf://<org>/{base}?")
        if require_exists:
            raise RuntimeError(hint)
        return resolved, f"model: {resolved} (local path; NOT PRESENT — dryrun only. {hint})"
    return resolved, f"model: {resolved} (local file)"


def resolve_submission(
    model: str,
    scheduler: str,
    name: str | None = None,
    require_exists: bool = True,
    remote_target: str = "",
) -> tuple[str, str, list[str]]:
    """Login-side resolution for a batch submission: classify the model and
    name the job. Hardware truths (accelerator/engine/image/port/runtime) are
    deliberately NOT resolved here — the inner `boxy serve` re-resolves them
    ON the compute node, where they are actually true (the design review's
    'wrong locus' fix). Returns (resolved_model, name, decisions)."""
    resolved_model, model_decision = _classify_model(model, require_exists, remote_target)
    decisions = [
        model_decision,
        f"scheduler: {scheduler} (submitting a batch job — detaches once READY)",
        "accelerator/engine/image/port: resolved on the compute node at job start",
    ]
    return resolved_model, name or _slug(model), decisions


def resolve(
    model: str,
    engine: str | None = None,
    runtime: str | None = None,
    scheduler: str | None = None,
    image: str | None = None,
    port: int | None = None,
    gpus: int = 0,
    nodes: int = 1,
    name: str | None = None,
    accelerator: str | None = None,
    here: bool = False,
    require_exists: bool = True,
    sources: dict | None = None,
    distributed: bool | None = None,
    remote_target: str = "",
) -> Resolution:
    decisions: list[str] = []
    resolved_model, model_decision = _classify_model(model, require_exists, remote_target)
    decisions.append(model_decision)

    location, loc_decisions = auto_location(
        runtime=runtime, scheduler=scheduler, accelerator=accelerator, gpus=gpus, nodes=nodes,
        here=here, sources=sources, distributed=distributed
    )
    decisions += loc_decisions

    if engine is None:
        # a path verified on the --ssh cluster (_classify_model's note) is REAL:
        # infer the engine from it like any existing path — the 'assume
        # llama.cpp' fallback sent a shared-FS HF DIRECTORY into the llama.cpp
        # image, which died on 'failed to read magic' (field)
        exists_remote = "verified over ssh" in model_decision
        if (not resolved_model.startswith(TRANSPORT_SCHEMES) and not resolved_model.startswith("s3://")
                and not os.path.exists(resolved_model) and not exists_remote):
            # dryrun with a missing path: don't assert facts about a file that
            # doesn't exist (finding 22) — plan as llama.cpp and say so
            engine = "llama.cpp"
            decisions.append("engine: llama.cpp (assumed — model file not present)")
        else:
            engine, why = infer_engine(model, location.accelerator, gpus=gpus)
            decisions.append(f"engine: {engine} ({why})")
    else:
        decisions.append(f"engine: {engine} (--engine)")

    resolved_image = image or ""
    if image:
        decisions.append(f"image: {image} (--image)")
    else:
        preview = ramalama_shim.default_image(engine, location.accelerator)
        decisions.append(f"image: {preview} (default for {engine}+{location.accelerator})")

    if port is not None:
        resolved_port = port
        decisions.append(f"port: {resolved_port} (--port)")
    else:
        default_port = 8000 if engine == "vllm" else 8090
        if location.scheduler == "none":
            resolved_port, busy_note = _free_port(default_port)
            decisions.append(f"port: {resolved_port} ({engine} default{busy_note})")
        else:
            # bind-testing the submitting node says nothing about the compute node
            resolved_port = default_port
            decisions.append(f"port: {resolved_port} ({engine} default; on the compute node)")

    # Model-card engine args (e.g. max_model_len for the 70B cards) merge in at
    # box.args level — the tack-on-last rule still lets explicit user args win.
    # Only REAL cards contribute args (the size heuristic knows geometry, not
    # flags). This runs wherever the box is actually built — locally AND on the
    # compute node of a batch job (same wheel, same packaged cards) — so card
    # args need no extra flag plumbing through the scheduler.
    from boxy import cards as _cards

    card_args, card_label = _cards.layered_args(resolved_model)
    if card_args:
        kv = ", ".join(f"{k}={v}" for k, v in card_args.items())
        decisions.append(f"engine args: {kv} ({card_label})")
    card_pip = _cards.layered_pip(resolved_model)
    if card_pip:
        decisions.append(f"pip: {' '.join(card_pip)} (installed in the container at start — "
                         f"the model's custom code imports them; the engine image doesn't ship them)")

    box_name = name or _slug(model)
    box = Box(
        name=box_name,
        image=resolved_image,  # "" -> deploy fills in default_image (same map as preview)
        engine=engine,
        model=resolved_model,
        ports=[resolved_port],
        args=card_args,
        pip=card_pip,
    )
    return Resolution(box=box, location=location, decisions=decisions)
